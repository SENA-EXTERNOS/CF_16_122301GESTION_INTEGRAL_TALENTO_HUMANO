function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6N6ruQGnMuq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

